<?php
require __DIR__.'/vendor/autoload.php';
$app = require __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$rows = Illuminate\Support\Facades\DB::connection('sqlsrv_payroll')
  ->table('dbo.t_allowance')
  ->whereRaw('LTRIM(RTRIM(office_name))=?',['002'])
  ->orderByRaw('ISNULL(display_order,9999) asc')
  ->orderBy('allowance_no')
  ->get(['allowance_no','allowance_name','amount_column_key','slot_no']);

foreach($rows as $r){
  echo (string)$r->allowance_no."\t".(string)$r->allowance_name."\t".(string)$r->amount_column_key."\t".(string)$r->slot_no."\n";
}
