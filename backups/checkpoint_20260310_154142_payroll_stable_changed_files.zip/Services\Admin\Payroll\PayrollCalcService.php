<?php

namespace App\Services\Admin\Payroll;

use App\Http\Controllers\Admin\LegacyPayrollController;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PayrollCalcService
{
    public function __construct(private readonly LegacyPayrollController $legacy)
    {
    }

    public function lock(Request $request): RedirectResponse
    {
        return $this->legacy->lock($request);
    }

    public function unlock(Request $request): RedirectResponse
    {
        return $this->legacy->unlock($request);
    }

    public function toggleLock(Request $request): RedirectResponse
    {
        return $this->legacy->toggleLock($request);
    }

    public function save(Request $request): RedirectResponse
    {
        return $this->legacy->save($request);
    }

    public function recalcKoyou(Request $request): RedirectResponse
    {
        return $this->legacy->recalcKoyou($request);
    }

    public function recalcPremiumDeduction(Request $request): RedirectResponse
    {
        return redirect()->route('admin.payroll.index', $this->buildQuery($request))
            ->with('status', '割増・控除再計算は次の分離フェーズで実装します。');
    }

    public function recalcIncomeTax(Request $request): RedirectResponse
    {
        return redirect()->route('admin.payroll.index', $this->buildQuery($request))
            ->with('status', '所得税再計算は次の分離フェーズで実装します。');
    }

    private function buildQuery(Request $request): array
    {
        $query = [
            'month' => (string) $request->input('month', ''),
            'staff_id' => (string) $request->input('staff_id', ''),
            'company_id' => (string) $request->input('company_id', ''),
            'row' => (string) $request->input('row', ''),
        ];

        return array_filter($query, static fn (string $v): bool => $v !== '');
    }
}
