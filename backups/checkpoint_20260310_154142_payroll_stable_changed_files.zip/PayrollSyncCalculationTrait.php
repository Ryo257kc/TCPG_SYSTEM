<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\DB;

trait PayrollSyncCalculationTrait
{
    private function applyPremiumDeductionFromAttendance(array &$payload, string $staffId): void
    {
        $isHourly = mb_strpos($this->resolveStaffDivision($staffId), 'パート') !== false;
        $overtimeHours = max(0.0, $this->payloadNumber($payload, 'overtime'));
        $nightHours = max(0.0, $this->payloadNumber($payload, 'night_over_time'));
        $holidayHours = max(0.0, $this->payloadNumber($payload, 'work_time_num'));
        $lateHours = max(0.0, $this->payloadNumber($payload, 'late_time'));
        $absenceDays = max(0.0, $this->payloadNumber($payload, 'absence_num'));

        $hourlyRate = 0.0;
        $deductionHourlyRate = 0.0;

        if ($isHourly) {
            $hourlyRate = max(
                0.0,
                $this->payloadNumber($payload, 'allowance_amo_1'),
                $this->payloadNumber($payload, 'basic_salary')
            );
            $deductionHourlyRate = $hourlyRate;
        } else {
            $bases = $this->resolvePremiumDeductionBases($payload, $staffId);
            $workingHours = $this->resolveMonthlyWorkingHours($staffId, $payload);
            if ($workingHours > 0) {
                $hourlyRate = max(0.0, $bases['premium_base'] / $workingHours);
                $deductionHourlyRate = max(0.0, $bases['deduction_base'] / $workingHours);
            }
        }

        $overtimePay = round($hourlyRate * 1.25 * $overtimeHours, 0, PHP_ROUND_HALF_UP);
        $nightPay = round($hourlyRate * 0.25 * $nightHours, 0, PHP_ROUND_HALF_UP);
        $holidayPay = round($hourlyRate * 1.25 * $holidayHours, 0, PHP_ROUND_HALF_UP);
        $lateDeduction = round($deductionHourlyRate * $lateHours, 0, PHP_ROUND_HALF_UP);
        $absenceDeduction = round($deductionHourlyRate * 8.0 * $absenceDays, 0, PHP_ROUND_HALF_UP);

        $payload['allowance_amo_8'] = $this->normalizeNumericInput($overtimePay);
        $payload['allowance_amo_9'] = $this->normalizeNumericInput($nightPay);
        $payload['allowance_amo_7'] = $this->normalizeNumericInput($holidayPay);
        $payload['late_deduction'] = $this->normalizeNumericInput($lateDeduction > 0 ? -$lateDeduction : 0);
        $payload['absence_deduction'] = $this->normalizeNumericInput($absenceDeduction > 0 ? -$absenceDeduction : 0);
    }

    private function applyIncomeTaxFromRules(array &$payload, string $staffId): void
    {
        $staffId = trim($staffId);
        if ($staffId === '') {
            return;
        }

        $syahoAfter = max(0.0, $this->payloadNumber($payload, 'taxation_sum') - $this->payloadNumber($payload, 'syaho_sum'));
        $payload['syaho_deduction_sum'] = $this->normalizeNumericInput($syahoAfter);

        $taxTable = trim((string) ($this->resolveStaffTaxAmount($staffId) ?: '甲欄'));
        if ($taxTable !== '甲欄') {
            return;
        }

        if ($syahoAfter < 88000) {
            $payload['income_tax'] = 0;
            return;
        }

        $salaryDeduction = 0.0;
        if ($syahoAfter <= 135416) {
            $salaryDeduction = 45834;
        } elseif ($syahoAfter <= 149999) {
            $salaryDeduction = floor($syahoAfter * 0.4) - 8333;
        } elseif ($syahoAfter <= 299999) {
            $salaryDeduction = floor($syahoAfter * 0.3 + 6667);
        } elseif ($syahoAfter <= 549999) {
            $salaryDeduction = floor($syahoAfter * 0.2 + 36667);
        } elseif ($syahoAfter <= 708330) {
            $salaryDeduction = floor($syahoAfter * 0.1 + 91667);
        } else {
            $salaryDeduction = 162500;
        }

        $kiso = 0.0;
        if ($syahoAfter <= 2162499) {
            $kiso = 40000;
        } elseif ($syahoAfter <= 2204166) {
            $kiso = 26667;
        } elseif ($syahoAfter <= 2245833) {
            $kiso = 13334;
        }

        $fuyoCount = max(0.0, $this->payloadNumber($payload, 'fuyo_sum'));
        $fuyoDeduction = ($fuyoCount * 31667) + $kiso;
        $taxableBase = max(0.0, $syahoAfter - $salaryDeduction - $fuyoDeduction);

        $incomeTax = 0.0;
        if ($taxableBase <= 162500) {
            $incomeTax = round(($taxableBase * 0.05105) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } elseif ($taxableBase <= 275000) {
            $incomeTax = round((($taxableBase * 0.1021) - 8296) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } elseif ($taxableBase <= 579166) {
            $incomeTax = round((($taxableBase * 0.2042) - 36374) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } elseif ($taxableBase <= 750000) {
            $incomeTax = round((($taxableBase * 0.23483) - 54113) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } elseif ($taxableBase <= 1500000) {
            $incomeTax = round((($taxableBase * 0.33693) - 130688) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } elseif ($taxableBase <= 3333333) {
            $incomeTax = round((($taxableBase * 0.4084) - 237893) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        } else {
            $incomeTax = round((($taxableBase * 0.45945) - 408061) / 10, 0, PHP_ROUND_HALF_UP) * 10;
        }

        if (mb_strpos($this->resolveStaffDivision($staffId), '業務委託') !== false) {
            $incomeTax = 0.0;
        }

        $payload['income_tax'] = $this->normalizeNumericInput(max(0.0, $incomeTax));
    }

    private function applySyncCalculationPipeline(array &$payload, string $staffId, string $payrollDate): void
    {
        $this->applyPremiumDeductionFromAttendance($payload, $staffId);
        $this->applyComputedTotals($payload, $staffId, $payrollDate);
        $this->applyEmploymentInsurance($payload, $staffId, $payrollDate);
        $this->applyComputedTotals($payload, $staffId, $payrollDate);
        $this->applyIncomeTaxFromRules($payload, $staffId);
        $this->applyComputedTotals($payload, $staffId, $payrollDate);
    }

    private function resolveStaffTaxAmount(string $staffId): string
    {
        $staffId = trim($staffId);
        if ($staffId === '') {
            return '';
        }

        try {
            $row = DB::connection('sqlsrv')
                ->table('dbo.m_staffs')
                ->whereRaw('LTRIM(RTRIM(staff_code)) = ?', [$staffId])
                ->first(['tax_amount']);

            return trim((string) ($row->tax_amount ?? ''));
        } catch (\Throwable) {
            return '';
        }
    }

    private function resolvePremiumDeductionBases(array $payload, string $staffId): array
    {
        $staffId = trim($staffId);
        $companyCode = $this->resolveStaffCompanyCode($staffId);
        $defs = $this->resolveAllowanceDefinitionsOrdered($companyCode);

        $premiumBase = 0.0;
        $deductionBase = 0.0;

        foreach ($defs as $def) {
            $key = trim((string) ($def['amount_column_key'] ?? ''));
            if ($key === '') {
                $slotNo = (int) ($def['slot_no'] ?? 0);
                if ($slotNo > 0) {
                    $key = 'allowance_amo_' . $slotNo;
                }
            }
            if ($key === '') {
                continue;
            }

            $amount = $this->payloadNumber($payload, $key);
            if ((int) ($def['warimasi_kiso'] ?? 0) === 1) {
                $premiumBase += $amount;
            }
            if ((int) ($def['koujyo_kiso'] ?? 0) === 1) {
                $deductionBase += $amount;
            }
        }

        if ($premiumBase <= 0) {
            $premiumBase = max(
                0.0,
                $this->payloadNumber($payload, 'allowance_amo_1'),
                $this->payloadNumber($payload, 'basic_salary')
            );
        }
        if ($deductionBase <= 0) {
            $deductionBase = max(
                0.0,
                $this->payloadNumber($payload, 'allowance_amo_1'),
                $this->payloadNumber($payload, 'basic_salary')
            );
        }

        return [
            'premium_base' => $premiumBase,
            'deduction_base' => $deductionBase,
        ];
    }

    private function resolveMonthlyWorkingHours(string $staffId, array $payload): float
    {
        $staffId = trim($staffId);
        if ($staffId !== '') {
            try {
                $row = DB::connection('sqlsrv')
                    ->table('dbo.m_staffs')
                    ->whereRaw('LTRIM(RTRIM(staff_code)) = ?', [$staffId])
                    ->first(['year_working_time']);

                $value = (float) ($this->normalizeNumericInput($row->year_working_time ?? 0));
                if ($value > 0) {
                    return $value;
                }
            } catch (\Throwable) {
                // no-op
            }
        }

        $fallback = $this->payloadNumber($payload, 'year_working_time');
        return $fallback > 0 ? $fallback : 0.0;
    }
}

