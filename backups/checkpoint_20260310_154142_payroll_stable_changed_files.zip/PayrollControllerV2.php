<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class PayrollControllerV2 extends Controller
{
    public function __construct(private readonly PayrollController $legacy)
    {
    }

    public function index(Request $request): View
    {
        return $this->legacy->index($request);
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        return $this->legacy->exportCsv($request);
    }

    public function lock(Request $request): RedirectResponse
    {
        return $this->toggleEditLock($request, true);
    }

    public function unlock(Request $request): RedirectResponse
    {
        return $this->toggleEditLock($request, false);
    }

    public function toggleLock(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'current_lock' => ['required', 'in:0,1'],
        ]);

        $nextLock = ((string) $validated['current_lock']) !== '1';
        return $this->toggleEditLock($request, $nextLock);
    }

    public function save(Request $request): RedirectResponse
    {
        return $this->legacy->save($request);
    }

    public function recalcKoyou(Request $request): RedirectResponse
    {
        return $this->legacy->recalcKoyou($request);
    }

    public function recalcPremiumDeduction(Request $request): RedirectResponse
    {
        return $this->legacy->recalcPremiumDeduction($request);
    }

    public function recalcIncomeTax(Request $request): RedirectResponse
    {
        return $this->legacy->recalcIncomeTax($request);
    }

    public function syncAttendance(Request $request): RedirectResponse
    {
        return $this->legacy->syncAttendance($request);
    }

    public function syncAttendanceBulk(Request $request): RedirectResponse
    {
        return $this->legacy->syncAttendanceBulk($request);
    }

    public function seedBulkCreate(Request $request): RedirectResponse
    {
        return $this->legacy->seedBulkCreate($request);
    }

    public function seedBulkDelete(Request $request): RedirectResponse
    {
        return $this->legacy->seedBulkDelete($request);
    }

    private function toggleEditLock(Request $request, bool $lock): RedirectResponse
    {
        $validated = $request->validate([
            'month' => ['required', 'regex:/^\d{4}-\d{2}$/'],
            'target_staff_id' => ['nullable', 'string', 'max:50'],
            'staff_id' => ['nullable', 'string', 'max:50'],
            'company_id' => ['nullable', 'string', 'max:200'],
            'row' => ['nullable', 'string', 'max:100'],
        ]);

        [$year, $month] = [(int) substr((string) $validated['month'], 0, 4), (int) substr((string) $validated['month'], 5, 2)];
        $targetStaffId = trim((string) ($validated['target_staff_id'] ?? ''));
        if ($targetStaffId === '') {
            $targetStaffId = trim((string) ($validated['staff_id'] ?? ''));
        }

        if ($targetStaffId !== '') {
            DB::connection('sqlsrv_payroll')
                ->table('dbo.m_payroll_entries')
                ->where('is_bonus', 0)
                ->whereRaw('YEAR([supply_month]) = ?', [$year])
                ->whereRaw('MONTH([supply_month]) = ?', [$month])
                ->whereRaw('LTRIM(RTRIM(staff_code)) = ?', [$targetStaffId])
                ->update(['is_edit_locked' => $lock ? 1 : 0]);
        }

        return $this->redirectPayrollV2WithQuery(
            $validated,
            $lock ? '給与を確定しました。' : '給与を未確定に戻しました。'
        );
    }

    private function redirectPayrollV2WithQuery(array $validated, string $message): RedirectResponse
    {
        $query = [
            'month' => (string) ($validated['month'] ?? now('Asia/Tokyo')->format('Y-m')),
        ];

        $staffFilter = trim((string) ($validated['staff_id'] ?? ''));
        if ($staffFilter !== '') {
            $query['staff_id'] = $staffFilter;
        }
        if (!empty($validated['company_id'])) {
            $query['company_id'] = (string) $validated['company_id'];
        }
        if (!empty($validated['row'])) {
            $query['row'] = (string) $validated['row'];
        }

        return redirect()
            ->route('admin.payroll-v2.index', $query)
            ->with('status', $message);
    }
}
