<?php
require __DIR__.'/vendor/autoload.php';
$app = require __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();
foreach (['t_allowance','dbo.t_allowance'] as $t) {
  try {
    $cols = Illuminate\Support\Facades\Schema::connection('sqlsrv_payroll')->getColumnListing($t);
    echo 'TABLE:'.$t.PHP_EOL;
    echo implode(PHP_EOL, $cols).PHP_EOL;
  } catch (Throwable $e) {
    echo 'ERR:'.$t.' '.$e->getMessage().PHP_EOL;
  }
}
