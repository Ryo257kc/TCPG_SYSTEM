<?php

namespace App\Services\Admin\Payroll;

use App\Http\Controllers\Admin\LegacyPayrollController;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class PayrollReadService
{
    public function __construct(private readonly LegacyPayrollController $legacy)
    {
    }

    public function index(Request $request): View
    {
        return $this->legacy->index($request);
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        return $this->legacy->exportCsv($request);
    }
}
