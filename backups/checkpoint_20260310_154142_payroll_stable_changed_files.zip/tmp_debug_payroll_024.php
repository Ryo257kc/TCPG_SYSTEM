<?php
require __DIR__.'/vendor/autoload.php';
$app = require __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$entry = Illuminate\Support\Facades\DB::connection('sqlsrv_payroll')
  ->table('dbo.m_payroll_entries')
  ->where('is_bonus',0)
  ->whereRaw('YEAR([supply_month])=?',[2026])
  ->whereRaw('MONTH([supply_month])=?',[2])
  ->whereRaw('LTRIM(RTRIM(staff_code))=?',['024'])
  ->orderBy('payroll_entry_id','desc')
  ->first(['payroll_entry_id','raw_payload']);

if(!$entry){ echo "NO_ENTRY\n"; exit; }
$p = json_decode((string)$entry->raw_payload,true) ?: [];
$keys = ['basic_salary','allowance_amo_1','allowance_amo_10','allowance_amo_2','allowance_amo_16'];
echo "ENTRY_ID=".$entry->payroll_entry_id."\n";
foreach($keys as $k){ echo $k.'='.(array_key_exists($k,$p)?(string)$p[$k]:'<missing>')."\n"; }
