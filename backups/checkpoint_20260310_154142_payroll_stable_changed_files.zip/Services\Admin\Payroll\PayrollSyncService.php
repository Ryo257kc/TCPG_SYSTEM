<?php

namespace App\Services\Admin\Payroll;

use App\Http\Controllers\Admin\LegacyPayrollController;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PayrollSyncService
{
    public function __construct(private readonly LegacyPayrollController $legacy)
    {
    }

    public function syncAttendance(Request $request): RedirectResponse
    {
        return $this->legacy->syncAttendance($request);
    }

    public function syncAttendanceBulk(Request $request): RedirectResponse
    {
        return $this->legacy->syncAttendanceBulk($request);
    }
}
