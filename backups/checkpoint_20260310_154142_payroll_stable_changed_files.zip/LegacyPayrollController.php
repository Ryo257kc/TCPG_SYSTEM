<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

/**
 * Legacy退避用スタブ。
 * 旧実装は checkpoint バックアップを参照。
 */
class LegacyPayrollController extends Controller
{
}
