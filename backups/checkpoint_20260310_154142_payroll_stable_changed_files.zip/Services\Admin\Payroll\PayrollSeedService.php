<?php

namespace App\Services\Admin\Payroll;

use App\Http\Controllers\Admin\LegacyPayrollController;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PayrollSeedService
{
    public function __construct(private readonly LegacyPayrollController $legacy)
    {
    }

    public function seedBulkCreate(Request $request): RedirectResponse
    {
        return $this->legacy->seedBulkCreate($request);
    }

    public function seedBulkDelete(Request $request): RedirectResponse
    {
        return $this->legacy->seedBulkDelete($request);
    }
}
