<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class PayrollV2Controller extends Controller
{
        private const SECTION_KEYS = [
        'BaseInfo' => [
            'kyuyo_sho_no', 'kyuyo_staff_id', 'staff_name', 'supply_month', 'section',
            'attendance_checked', 'attendance_checked_at', 'attendance_checked_by',
            'bonus', 'bonus_amo', 'edit_lock',
        ],
        'Attendance' => [
            'peple_num', 'km', 'work_in_num', 'absence_num', 'work_time', 'work_time_num',
            'work_horiday_num', 'overtime', 'night_over_time', 'late_time',
            'late_deduction', 'absence_deduction', 'horiday_true', 'horiday_true_num',
            'days_closed', 'time_closed',
        ],
        'Earnings' => [
            'basic_salary', 'officer_com', 'allowance_amo_1', 'allowance_amo_2', 'allowance_amo_3',
            'allowance_amo_4', 'allowance_amo_5', 'allowance_amo_6', 'allowance_amo_7',
            'allowance_amo_8', 'allowance_amo_9', 'allowance_amo_10', 'allowance_amo_11',
            'allowance_amo_12', 'allowance_amo_13', 'allowance_amo_14', 'allowance_amo_15',
            'allowance_amo_16', 'allowance_amo_17', 'leave_allowance', 'traffic_addition',
            'fuyo_sum', 'taxation_sum', 'not_taxation_sum', 'supply_sum', 'pay_total',
        ],
        'Deductions' => [
            'kenpo', 'kaigo', 'kounen', 'koyou', 'income_tax', 'resident_tax',
            'rent_cost', 'adjustment_cost', 'syaho_sum', 'deduction_sum',
            'syaho_deduction_sum', 'supply_deduction_sum', 'koujo_total',
            'salary_total', 'deduction_total', 'net_pay', 'transfer_amo',
            'rouho_target_sum', 'syaho_target_sum',
        ],
        'Sales' => [
            'unpaid_amo', 'kitazaike', 'higashi_kakogawa', 'tsubasa_harima', 'own_cost',
            'sakura_hari', 'orita_hari', 'miyamoto_hari', 'yokoi_hari',
        ],
        'Others' => [
            'kotei_sum', 'yakuin_sum', 'adjustment_year_end', 'koujyo_1',
            'cost_liquidation', 'transfer_balance', 'company_advance_cost',
            'not_syaho', 'not_rouho', 'not_supply', 'koyou_office', 'jidou_office', 'rousai_office',
        ],
    ];

    private const EDITABLE_KEYS = [
        'work_in_num', 'absence_num', 'work_time', 'work_horiday_num', 'overtime', 'night_over_time',
        'late_time', 'horiday_true', 'horiday_true_num', 'days_closed', 'time_closed',

        'basic_salary', 'officer_com', 'leave_allowance', 'traffic_addition',
        'allowance_amo_1', 'allowance_amo_2', 'allowance_amo_3', 'allowance_amo_4', 'allowance_amo_5',
        'allowance_amo_6', 'allowance_amo_7', 'allowance_amo_8', 'allowance_amo_9', 'allowance_amo_10',
        'allowance_amo_11', 'allowance_amo_12', 'allowance_amo_13', 'allowance_amo_14',
        'allowance_amo_15', 'allowance_amo_16', 'allowance_amo_17',

        'kenpo', 'kaigo', 'kounen', 'koyou', 'income_tax', 'resident_tax',
        'rent_cost', 'adjustment_cost',

        'adjustment_year_end', 'koujyo_1', 'unpaid_amo', 'cost_liquidation',
        'kitazaike', 'higashi_kakogawa', 'tsubasa_harima', 'own_cost',
        'sakura_hari', 'orita_hari', 'miyamoto_hari', 'yokoi_hari',
    ];

    public function index(Request $request): View
    {
        $bonusColumn = $this->payrollColumn('is_bonus', 'bonus');
        $staffCodeColumn = $this->payrollColumn('staff_code', 'kyuyo_staff_id');
        $entryIdColumn = $this->payrollColumn('payroll_entry_id', 'kyuyo_sho_no');
        $payloadColumn = $this->payrollColumn('raw_payload', null);

        $availableMonths = DB::connection('sqlsrv_payroll')
            ->table('dbo.m_payroll_entries')
            ->selectRaw('YEAR([supply_month]) as y, MONTH([supply_month]) as m')
            ->where($bonusColumn, 0)
            ->whereNotNull('supply_month')
            ->groupByRaw('YEAR([supply_month]), MONTH([supply_month])')
            ->orderByRaw('YEAR([supply_month]) desc, MONTH([supply_month]) desc')
            ->get()
            ->map(fn ($row) => sprintf('%04d-%02d', (int) $row->y, (int) $row->m))
            ->values()
            ->all();

        $selectedMonth = (string) $request->query('month', $availableMonths[0] ?? now('Asia/Tokyo')->format('Y-m'));
        if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonth)) {
            $selectedMonth = $availableMonths[0] ?? now('Asia/Tokyo')->format('Y-m');
        }
        [$year, $month] = [(int) substr($selectedMonth, 0, 4), (int) substr($selectedMonth, 5, 2)];

        $selectedCompanyId = trim((string) $request->query('company_id', ''));
        $selectedStaffId = trim((string) $request->query('staff_id', ''));

        $companyOptions = DB::connection('sqlsrv')
            ->table('dbo.m_stores')
            ->select('company_name')
            ->whereNotNull('company_name')
            ->whereRaw('LTRIM(RTRIM(company_name)) <> ?', [''])
            ->distinct()
            ->orderBy('company_name')
            ->get()
            ->map(fn ($row) => [
                'company_id' => (string) $row->company_name,
                'company_name' => (string) $row->company_name,
            ])
            ->values()
            ->all();

        $staffIdColumn = $this->staffColumn('staff_code', 'staff_id');
        $staffStoreColumn = $this->staffColumn('store_code', 'section');
        $staffDivisionExpr = $this->staffDivisionSelectExpr();

        $staffQuery = DB::connection('sqlsrv')
            ->table('dbo.m_staffs as ms')
            ->leftJoin('dbo.m_stores as st', 'ms.' . $staffStoreColumn, '=', 'st.store_code')
            ->whereNotNull('ms.' . $staffIdColumn)
            ->whereRaw('LTRIM(RTRIM(ms.' . $staffIdColumn . ')) <> ?', [''])
            ->selectRaw('LTRIM(RTRIM(ms.' . $staffIdColumn . ')) as staff_id, ms.staff_name, ' . $staffDivisionExpr . ' as staff_division, st.company_name, st.store_short_name');

        if ($selectedCompanyId !== '') {
            $staffQuery->where('st.company_name', $selectedCompanyId);
        }

        $staffOptions = $staffQuery
            ->orderBy('ms.' . $staffIdColumn)
            ->get()
            ->map(fn ($row) => [
                'staff_id' => trim((string) ($row->staff_id ?? '')),
                'staff_name' => trim((string) ($row->staff_name ?? '')),
                'staff_division' => trim((string) ($row->staff_division ?? '')),
                'company_name' => trim((string) ($row->company_name ?? '')),
                'store_short_name' => trim((string) ($row->store_short_name ?? '')),
            ])
            ->filter(fn ($row) => $row['staff_id'] !== '')
            ->values()
            ->all();

        $staffNameMap = [];
        $staffMetaMap = [];
        foreach ($staffOptions as $staff) {
            $id = (string) $staff['staff_id'];
            $staffNameMap[$id] = (string) $staff['staff_name'];
            $staffMetaMap[$id] = $staff;
        }

        $rowsQuery = DB::connection('sqlsrv_payroll')
            ->table('dbo.m_payroll_entries')
            ->where($bonusColumn, 0)
            ->whereRaw('YEAR([supply_month]) = ?', [$year])
            ->whereRaw('MONTH([supply_month]) = ?', [$month]);

        if ($selectedStaffId !== '') {
            $rowsQuery->whereRaw('LTRIM(RTRIM(' . $staffCodeColumn . ')) = ?', [$selectedStaffId]);
        }

        if ($selectedCompanyId !== '') {
            $companyStaffIds = array_values(array_unique(array_map(
                fn ($row) => (string) ($row['staff_id'] ?? ''),
                array_filter($staffOptions, fn ($row) => (string) ($row['company_name'] ?? '') === $selectedCompanyId)
            )));
            if ($companyStaffIds === []) {
                $rowsQuery->whereRaw('1 = 0');
            } else {
                $rowsQuery->whereIn(DB::raw('LTRIM(RTRIM(' . $staffCodeColumn . '))'), $companyStaffIds);
            }
        }

        $entryRows = $rowsQuery
            ->orderByRaw('LTRIM(RTRIM(' . $staffCodeColumn . ')) ASC')
            ->orderBy($entryIdColumn, 'desc')
            ->get();

        $summaryRows = [];
        $rowByStaff = [];

        foreach ($entryRows as $row) {
            $staffId = trim((string) ($row->{$staffCodeColumn} ?? ''));
            if ($staffId === '' || isset($rowByStaff[$staffId])) {
                continue;
            }

            $payload = $payloadColumn !== null ? $this->decodePayload($row->{$payloadColumn} ?? null) : [];

            $payTotal = $this->pickFirst([
                $row->payment_total ?? null,
                $payload['payment_total'] ?? null,
                $payload['sikyu_total'] ?? null,
                $payload['pay_total'] ?? null,
                $payload['supply_sum'] ?? null,
            ]);
            $deductTotal = $this->pickFirst([
                $payload['deduction_total'] ?? null,
                $payload['koujo_total'] ?? null,
                $payload['deduction_sum'] ?? null,
                $row->salary_total ?? null,
            ]);
            $netPay = $this->pickFirst([
                $payload['supply_deduction_sum'] ?? null,
                $payload['net_pay'] ?? null,
                $payload['transfer_amo'] ?? null,
                $row->transfer_amount ?? null,
            ]);

            $item = [
                'payroll_entry_id' => (int) ($row->{$entryIdColumn} ?? 0),
                'staff_id' => $staffId,
                'staff_name' => (string) ($staffNameMap[$staffId] ?? ''),
                'staff_division' => (string) (($staffMetaMap[$staffId]['staff_division'] ?? '') ?: ''),
                'company_name' => (string) (($staffMetaMap[$staffId]['company_name'] ?? '') ?: ''),
                'store_short_name' => (string) (($staffMetaMap[$staffId]['store_short_name'] ?? '') ?: ''),
                'supply_month' => (string) ($row->supply_month ?? ''),
                'pay_total' => $this->fmtYen($payTotal),
                'deduction_total' => $this->fmtYen($deductTotal),
                'net_pay' => $this->fmtYen($netPay),
                'is_edit_locked' => ((int) ($row->is_edit_locked ?? 0)) === 1,
                'attendance_checked' => ((int) ($payload['attendance_checked'] ?? 0)) === 1,
            ];
            $rowByStaff[$staffId] = ['summary' => $item, 'payload' => $payload];
            $summaryRows[] = $item;
        }

        if ($selectedStaffId === '' && $summaryRows !== []) {
            $selectedStaffId = (string) ($summaryRows[0]['staff_id'] ?? '');
        }

        $selectedSummary = null;
        $selectedPayloadSections = [];
        if ($selectedStaffId !== '' && isset($rowByStaff[$selectedStaffId])) {
            $selectedSummary = $rowByStaff[$selectedStaffId]['summary'];
            $selectedPayloadSections = $this->buildDisplayPayloadSections($rowByStaff[$selectedStaffId]['payload']);
        }

        return view('admin.payroll_v2.index', [
            'availableMonths' => $availableMonths,
            'selectedMonth' => $selectedMonth,
            'companyOptions' => $companyOptions,
            'selectedCompanyId' => $selectedCompanyId,
            'staffOptions' => $staffOptions,
            'selectedStaffId' => $selectedStaffId,
            'summaryRows' => $summaryRows,
            'selectedSummary' => $selectedSummary,
            'selectedPayloadSections' => $selectedPayloadSections,
            'editablePayloadKeys' => array_fill_keys(self::EDITABLE_KEYS, true),
            'bulkStaffRows' => $staffOptions,
        ]);
    }

    public function seedBulkCreate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'month' => ['required', 'regex:/^\d{4}-\d{2}$/'],
            'staff_id' => ['nullable', 'string', 'max:50'],
            'company_id' => ['nullable', 'string', 'max:200'],
            'target_staff_ids' => ['nullable', 'array'],
            'target_staff_ids.*' => ['string', 'max:50'],
        ]);

        [$year, $month] = [(int) substr((string) $validated['month'], 0, 4), (int) substr((string) $validated['month'], 5, 2)];
        $targets = collect((array) ($validated['target_staff_ids'] ?? []))
            ->map(fn ($v) => trim((string) $v))
            ->filter(fn ($v) => $v !== '')
            ->unique()
            ->values()
            ->all();

        $selectedStaffId = trim((string) ($validated['staff_id'] ?? ''));
        if ($targets === [] && $selectedStaffId !== '') {
            $targets = [$selectedStaffId];
        }
        if ($targets === []) {
            return $this->redirectV2($request)->with('error', 'No target staff selected.');
        }

        $bonusCol = $this->payrollColumn('is_bonus', 'bonus');
        $staffCol = $this->payrollColumn('staff_code', 'kyuyo_staff_id');
        $lockCol = $this->payrollColumn('is_edit_locked', 'edit_lock');

        $existingIds = DB::connection('sqlsrv_payroll')
            ->table('dbo.m_payroll_entries')
            ->where($bonusCol, 0)
            ->whereRaw('YEAR([supply_month]) = ?', [$year])
            ->whereRaw('MONTH([supply_month]) = ?', [$month])
            ->whereIn(DB::raw('LTRIM(RTRIM(' . $staffCol . '))'), $targets)
            ->selectRaw('DISTINCT LTRIM(RTRIM(' . $staffCol . ')) as staff_id')
            ->pluck('staff_id')
            ->map(fn ($v) => trim((string) $v))
            ->filter(fn ($v) => $v !== '')
            ->values()
            ->all();
        $existingMap = array_fill_keys($existingIds, true);

        $created = 0;
        $skipped = 0;
        $supplyDate = sprintf('%04d-%02d-20', $year, $month);

        foreach ($targets as $sid) {
            if (isset($existingMap[$sid])) {
                $skipped++;
                continue;
            }

            $insert = [
                $staffCol => $sid,
                'supply_month' => $supplyDate,
                $bonusCol => 0,
                $lockCol => 0,
            ];

            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'raw_payload')) {
                $insert['raw_payload'] = '{}';
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'payment_total')) {
                $insert['payment_total'] = 0;
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'salary_total')) {
                $insert['salary_total'] = 0;
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'transfer_amount')) {
                $insert['transfer_amount'] = 0;
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'bonus_amount')) {
                $insert['bonus_amount'] = 0;
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'created_at')) {
                $insert['created_at'] = now('Asia/Tokyo');
            }
            if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', 'updated_at')) {
                $insert['updated_at'] = now('Asia/Tokyo');
            }

            DB::connection('sqlsrv_payroll')->table('dbo.m_payroll_entries')->insert($insert);
            $created++;
        }

        return $this->redirectV2($request)->with('status', 'Payroll rows created: ' . $created . ' / skipped existing: ' . $skipped);
    }

    public function seedBulkDelete(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'month' => ['required', 'regex:/^\d{4}-\d{2}$/'],
            'staff_id' => ['nullable', 'string', 'max:50'],
            'company_id' => ['nullable', 'string', 'max:200'],
            'target_staff_ids' => ['nullable', 'array'],
            'target_staff_ids.*' => ['string', 'max:50'],
        ]);

        [$year, $month] = [(int) substr((string) $validated['month'], 0, 4), (int) substr((string) $validated['month'], 5, 2)];
        $targets = collect((array) ($validated['target_staff_ids'] ?? []))
            ->map(fn ($v) => trim((string) $v))
            ->filter(fn ($v) => $v !== '')
            ->unique()
            ->values()
            ->all();

        $selectedStaffId = trim((string) ($validated['staff_id'] ?? ''));
        if ($targets === [] && $selectedStaffId !== '') {
            $targets = [$selectedStaffId];
        }
        if ($targets === []) {
            return $this->redirectV2($request)->with('error', 'No target staff selected.');
        }

        $bonusCol = $this->payrollColumn('is_bonus', 'bonus');
        $staffCol = $this->payrollColumn('staff_code', 'kyuyo_staff_id');
        $entryIdCol = $this->payrollColumn('payroll_entry_id', 'kyuyo_sho_no');
        $lockCol = $this->payrollColumn('is_edit_locked', 'edit_lock');

        $entries = DB::connection('sqlsrv_payroll')
            ->table('dbo.m_payroll_entries')
            ->where($bonusCol, 0)
            ->whereRaw('YEAR([supply_month]) = ?', [$year])
            ->whereRaw('MONTH([supply_month]) = ?', [$month])
            ->whereIn(DB::raw('LTRIM(RTRIM(' . $staffCol . '))'), $targets)
            ->get([$entryIdCol . ' as entry_id', $lockCol . ' as lock_flag']);

        if ($entries->isEmpty()) {
            return $this->redirectV2($request)->with('status', 'No payroll rows to delete.');
        }

        $deleted = 0;
        $skippedLocked = 0;
        foreach ($entries as $entry) {
            if ((int) ($entry->lock_flag ?? 0) === 1) {
                $skippedLocked++;
                continue;
            }
            $deleted += DB::connection('sqlsrv_payroll')
                ->table('dbo.m_payroll_entries')
                ->where($entryIdCol, (int) $entry->entry_id)
                ->delete();
        }

        return $this->redirectV2($request)->with('status', 'Deleted: ' . $deleted . ' / skipped locked: ' . $skippedLocked);
    }

    public function syncAttendance(Request $request): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollEntryActionService $service */
            $service = app(\App\Services\Admin\Payroll\PayrollEntryActionService::class);
            $result = $service->syncAttendance($request, $this->attendanceAggregateService());
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }

        return $this->redirectFromActionResult($result, $request);
    }

    public function syncAttendanceBulk(Request $request): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollEntryActionService $service */
            $service = app(\App\Services\Admin\Payroll\PayrollEntryActionService::class);
            $result = $service->syncAttendanceBulk($request, $this->attendanceAggregateService());
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }

        return $this->redirectFromActionResult($result, $request);
    }

    public function recalcDefaults(Request $request): RedirectResponse
    {
        return $this->runCalculationAction($request, __FUNCTION__);
    }

    public function recalcKoyou(Request $request): RedirectResponse
    {
        return $this->runCalculationAction($request, __FUNCTION__);
    }

    public function recalcPremiumDeduction(Request $request): RedirectResponse
    {
        return $this->runCalculationAction($request, __FUNCTION__);
    }

    public function recalcIncomeTax(Request $request): RedirectResponse
    {
        return $this->runCalculationAction($request, __FUNCTION__);
    }

    public function save(Request $request): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollEntryActionService $service */
            $service = app(\App\Services\Admin\Payroll\PayrollEntryActionService::class);
            $result = $service->save($request);
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }

        return $this->redirectFromActionResult($result, $request);
    }

    public function lock(Request $request): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollEntryActionService $service */
            $service = app(\App\Services\Admin\Payroll\PayrollEntryActionService::class);
            $result = $service->toggleLock($request, true);
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }

        return $this->redirectFromActionResult($result, $request);
    }

    public function unlock(Request $request): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollEntryActionService $service */
            $service = app(\App\Services\Admin\Payroll\PayrollEntryActionService::class);
            $result = $service->toggleLock($request, false);
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }

        return $this->redirectFromActionResult($result, $request);
    }
    private function redirectFromActionResult(array $result, Request $request): RedirectResponse
    {
        $query = is_array($result['query'] ?? null) ? $result['query'] : array_filter([
            'month' => (string) $request->input('month', (string) $request->query('month', '')),
            'company_id' => (string) $request->input('company_id', (string) $request->query('company_id', '')),
            'staff_id' => (string) $request->input('staff_id', (string) $request->query('staff_id', '')),
            'row' => (string) $request->input('row', (string) $request->query('row', '')),
        ], static fn ($v) => $v !== '');

        $redirect = redirect()->route('admin.payroll-v2.index', $query);
        if (is_string($result['error'] ?? null) && $result['error'] !== '') {
            return $redirect->with('error', $result['error']);
        }
        if (is_string($result['status'] ?? null) && $result['status'] !== '') {
            return $redirect->with('status', $result['status']);
        }

        return $redirect;
    }

    private function attendanceAggregateService(): \App\Services\Admin\Payroll\AttendanceAggregateService
    {
        /** @var \App\Services\Admin\Payroll\AttendanceAggregateService $service */
        $service = app(\App\Services\Admin\Payroll\AttendanceAggregateService::class);

        return $service;
    }
    private function runCalculationAction(Request $request, string $action): RedirectResponse
    {
        try {
            /** @var \App\Services\Admin\Payroll\PayrollCalculationService $calc */
            $calc = app(\App\Services\Admin\Payroll\PayrollCalculationService::class);
            $result = $calc->execute($request, $action);
            return $this->redirectFromActionResult($result, $request);
        } catch (\Throwable $e) {
            return $this->redirectV2($request)->with('error', $e->getMessage());
        }
    }
    private function redirectV2(Request $request): RedirectResponse
    {
        $query = array_filter([
            'month' => (string) $request->input('month', (string) $request->query('month', '')),
            'company_id' => (string) $request->input('company_id', (string) $request->query('company_id', '')),
            'staff_id' => (string) $request->input('staff_id', (string) $request->query('staff_id', '')),
        ], static fn ($v) => $v !== '');

        return redirect()->route('admin.payroll-v2.index', $query);
    }

    private function decodePayload(mixed $rawPayload): array
    {
        if (!is_string($rawPayload) || trim($rawPayload) === '') {
            return [];
        }

        $decoded = json_decode($rawPayload, true);

        return is_array($decoded) ? $decoded : [];
    }

    private function pickFirst(array $values): mixed
    {
        foreach ($values as $v) {
            if ($v !== null && $v !== '') {
                return $v;
            }
        }

        return null;
    }

    private function fmtYen(mixed $value): string
    {
        if ($value === null || $value === '') {
            return '-';
        }

        if (is_numeric($value)) {
            return number_format((float) $value, 0);
        }

        return (string) $value;
    }

    private function buildDisplayPayloadSections(array $payload): array
    {
        $out = [];
        foreach (self::SECTION_KEYS as $section => $keys) {
            $bucket = [];
            foreach ($keys as $key) {
                $bucket[$key] = array_key_exists($key, $payload) ? $payload[$key] : 0;
            }
            $out[$section] = $bucket;
        }

        $covered = [];
        foreach ($out as $rows) {
            foreach (array_keys($rows) as $k) {
                $covered[$k] = true;
            }
        }

        $extras = [];
        foreach ($payload as $k => $v) {
            if (!is_string($k)) {
                continue;
            }
            if (!isset($covered[$k])) {
                $extras[$k] = $v;
            }
        }

        if ($extras !== []) {
            $out['Extras'] = $extras;
        }

        return $out;
    }

    private function payrollColumn(string $preferred, ?string $fallback): string
    {
        if (Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', $preferred)) {
            return $preferred;
        }
        if ($fallback !== null && Schema::connection('sqlsrv_payroll')->hasColumn('m_payroll_entries', $fallback)) {
            return $fallback;
        }

        return $preferred;
    }

    private function staffColumn(string $preferred, string $fallback): string
    {
        if (Schema::connection('sqlsrv')->hasColumn('m_staffs', $preferred)) {
            return $preferred;
        }
        if (Schema::connection('sqlsrv')->hasColumn('m_staffs', $fallback)) {
            return $fallback;
        }

        return $preferred;
    }

    private function staffDivisionSelectExpr(): string
    {
        $hasDivision = Schema::connection('sqlsrv')->hasColumn('m_staffs', 'staff_division');
        $hasEmploymentStatus = Schema::connection('sqlsrv')->hasColumn('m_staffs', 'employment_status');

        if ($hasDivision && $hasEmploymentStatus) {
            return 'ISNULL(ms.staff_division, ms.employment_status)';
        }
        if ($hasDivision) {
            return 'ms.staff_division';
        }
        if ($hasEmploymentStatus) {
            return 'ms.employment_status';
        }

        return "''";
    }
}
