<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll V2</title>
    <style>
        body { margin:0; font-family:"Segoe UI",sans-serif; background:#eef3fb; color:#111827; }
        .wrap { width:min(1760px,98vw); margin:14px auto; }
        .top { display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:10px; }
        .title { font-size:22px; font-weight:800; color:#1f4f8f; }
        .btn { display:inline-flex; align-items:center; height:32px; padding:0 10px; border-radius:8px; border:1px solid #cfd9e8; background:#fff; color:#1f2937; text-decoration:none; font-size:12px; cursor:pointer; }
        .btn.primary { background:#1f4f8f; border-color:#1f4f8f; color:#fff; }
        .btn.danger { border-color:#fecaca; background:#fff1f2; color:#b42318; }
        .panel { background:#fff; border:1px solid #d3dff0; border-radius:12px; padding:10px; }
        .filters { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-bottom:8px; }
        .filters label { font-size:12px; color:#475467; }
        .filters select, .filters input { height:32px; border:1px solid #cfd9e8; border-radius:8px; padding:0 10px; min-width:140px; }
        .seed { display:none; border:1px solid #d7e4f8; background:#f8fbff; border-radius:10px; padding:8px; margin-bottom:8px; }
        .seed.open { display:block; }
        .seed-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(170px,1fr)); gap:6px 10px; max-height:180px; overflow:auto; border:1px solid #dce7f7; background:#fff; border-radius:8px; padding:8px; }
        .seed-check { display:flex; align-items:center; gap:6px; font-size:12px; }
        .seed-actions { display:flex; gap:8px; align-items:center; margin-top:8px; flex-wrap:wrap; }
        .flash { margin:8px 0; border:1px solid #cfe0fb; background:#edf4ff; color:#1f4f8f; border-radius:8px; padding:8px 10px; font-size:13px; }
        .flash.error { border-color:#fecaca; background:#fff1f2; color:#b42318; }
        .layout { display:grid; grid-template-columns:250px 1fr; gap:10px; min-height:74vh; }
        .list { border:1px solid #dce7f7; background:#f8fbff; border-radius:10px; padding:6px; overflow:auto; }
        .item { display:block; text-decoration:none; color:inherit; border:1px solid #dce6f5; background:#fff; border-radius:8px; padding:6px 8px; margin-bottom:6px; }
        .item.active { border-color:#6aa0f0; box-shadow:0 0 0 2px rgba(106,160,240,.18); }
        .item-id { font-size:11px; color:#475467; display:flex; gap:6px; align-items:center; flex-wrap:wrap; }
        .item-name { font-size:14px; font-weight:700; margin-top:2px; }
        .pill { font-size:10px; border-radius:999px; padding:1px 6px; border:1px solid transparent; }
        .pill.lock { background:#d1fae5; border-color:#a7f3d0; color:#0f5132; }
        .pill.unlock { background:#ffedd5; border-color:#fed7aa; color:#9a3412; }
        .pill.ok { background:#dcfce7; border-color:#86efac; color:#166534; }
        .pill.ng { background:#fee4e2; border-color:#fecaca; color:#b42318; }
        .detail { border:1px solid #dce7f7; background:#f8fbff; border-radius:10px; padding:8px; }
        .cards { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px; margin-bottom:8px; }
        .card { background:#fff; border:1px solid #d9e5f7; border-radius:10px; padding:8px; }
        .k { font-size:11px; color:#667085; }
        .v { font-size:16px; font-weight:700; color:#1f2937; margin-top:3px; }
        .actions { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
        .payload { background:#fff; border:1px solid #d9e5f7; border-radius:10px; padding:8px; }
        .payload-grid { display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:8px; }
        .payload-section { border:1px solid #e5ecf8; border-radius:8px; overflow:auto; background:#fff; }
        .payload-title { font-size:12px; font-weight:700; color:#1f4f8f; padding:6px 8px; background:#f3f7ff; border-bottom:1px solid #e5ecf8; }
        table { width:100%; border-collapse:collapse; }
        th, td { border-bottom:1px solid #edf2fb; padding:6px 8px; font-size:12px; }
        th { width:280px; text-align:left; color:#334155; background:#f8fbff; }
        td { text-align:right; font-variant-numeric:tabular-nums; }
        .cell-view { display:inline; }
        .cell-input { display:none; width:100%; height:28px; border:1px solid #cfd9e8; border-radius:6px; padding:0 8px; text-align:right; }
        .payload.edit-mode .cell-view { display:none; }
        .payload.edit-mode .cell-input { display:inline-block; }
        .cell-readonly { color:#64748b; font-style:italic; }
        .payload.edit-mode .cell-readonly { display:inline; }
        .empty { text-align:center; color:#667085; padding:22px; }
        @media (max-width: 1100px) { .layout { grid-template-columns:1fr; } .cards { grid-template-columns:repeat(2,minmax(0,1fr)); } .payload-grid{grid-template-columns:repeat(2,minmax(0,1fr));} }
        @media (max-width: 760px) { .payload-grid{grid-template-columns:1fr;} }
    </style>
</head>
<body>
<div class="wrap">
    <div class="top">
        <div class="title">Admin Payroll V2</div>
        <div style="display:flex; gap:8px;">
            <a class="btn" href="{{ route('admin.payroll.index') }}">Payroll</a>
            <a class="btn" href="{{ route('admin.dashboard') }}">Dashboard</a>
        </div>
    </div>

    <section class="panel">
        <form method="GET" action="{{ route('admin.payroll-v2.index') }}" class="filters">
            <label for="month">Month</label>
            <input id="month" name="month" type="month" value="{{ $selectedMonth }}">

            <label for="company_id">Company</label>
            <select id="company_id" name="company_id">
                <option value="">All</option>
                @foreach($companyOptions as $co)
                    <option value="{{ $co['company_id'] }}" @selected($co['company_id'] === $selectedCompanyId)>{{ $co['company_name'] }}</option>
                @endforeach
            </select>

            <label for="staff_id">Staff</label>
            <select id="staff_id" name="staff_id">
                <option value="">Auto</option>
                @foreach($staffOptions as $st)
                    <option value="{{ $st['staff_id'] }}" @selected($st['staff_id'] === $selectedStaffId)>{{ $st['staff_id'] }} {{ $st['staff_name'] }}</option>
                @endforeach
            </select>

            <button type="submit" class="btn primary">Show</button>
            <button type="button" class="btn" onclick="toggleSeed()">Payroll Seed</button>
        </form>

        <form method="POST" action="{{ route('admin.payroll-v2.sync-attendance-bulk') }}" class="filters" style="margin-top:-4px;">
            @csrf
            <input type="hidden" name="month" value="{{ $selectedMonth }}">
            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
            <input type="hidden" name="staff_id" value="{{ $selectedStaffId }}">
            <button type="submit" class="btn">Bulk Sync Attendance</button>
        </form>

        <div id="seed-box" class="seed">
            <div class="seed-grid">
                @forelse($bulkStaffRows as $s)
                    <label class="seed-check">
                        <input type="checkbox" class="seed-target" value="{{ $s['staff_id'] }}" @checked($selectedStaffId !== '' && $selectedStaffId === $s['staff_id'])>
                        <span>{{ $s['staff_id'] }} {{ $s['staff_name'] }}</span>
                    </label>
                @empty
                    <div style="font-size:12px; color:#667085;">No staff rows.</div>
                @endforelse
            </div>
            <div class="seed-actions">
                <button type="button" class="btn" onclick="seedAll(true)">Select All</button>
                <button type="button" class="btn" onclick="seedAll(false)">Clear</button>

                <form id="seed-create" method="POST" action="{{ route('admin.payroll-v2.seed-bulk-create') }}" style="margin:0;">
                    @csrf
                    <input type="hidden" name="month" value="{{ $selectedMonth }}">
                    <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                    <input type="hidden" name="staff_id" value="{{ $selectedStaffId }}">
                    <button type="submit" class="btn primary" onclick="return injectTargets('seed-create')">Create Payroll Rows</button>
                </form>

                <form id="seed-delete" method="POST" action="{{ route('admin.payroll-v2.seed-bulk-delete') }}" style="margin:0;" onsubmit="return confirm('Delete payroll rows for selected staff?') && injectTargets('seed-delete');">
                    @csrf
                    <input type="hidden" name="month" value="{{ $selectedMonth }}">
                    <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                    <input type="hidden" name="staff_id" value="{{ $selectedStaffId }}">
                    <button type="submit" class="btn danger">Delete Payroll Rows</button>
                </form>
            </div>
        </div>

        @if(session('status'))
            <div class="flash">{{ session('status') }}</div>
        @endif
        @if(session('error'))
            <div class="flash error">{{ session('error') }}</div>
        @endif

        <div class="layout">
            <div class="list">
                @forelse($summaryRows as $row)
                    <a class="item @if(($selectedSummary['staff_id'] ?? '') === $row['staff_id']) active @endif"
                       href="{{ route('admin.payroll-v2.index', ['month' => $selectedMonth, 'company_id' => $selectedCompanyId, 'staff_id' => $row['staff_id']]) }}">
                        <div class="item-id">
                            <span>{{ $row['staff_id'] }}</span>
                            @if($row['is_edit_locked'])<span class="pill lock">Locked</span>@else<span class="pill unlock">Unlocked</span>@endif
                            @if($row['attendance_checked'])<span class="pill ok">Att OK</span>@else<span class="pill ng">Att NG</span>@endif
                        </div>
                        <div class="item-name">{{ $row['staff_name'] !== '' ? $row['staff_name'] : '-' }}</div>
                        <div class="item-id">{{ $row['staff_division'] !== '' ? $row['staff_division'] : '-' }} / {{ $row['store_short_name'] !== '' ? $row['store_short_name'] : '-' }}</div>
                    </a>
                @empty
                    <div class="empty">No payroll rows.</div>
                @endforelse
            </div>

            <div class="detail">
                @if($selectedSummary === null)
                    <div class="empty">Select a staff row.</div>
                @else
                    <div class="cards">
                        <div class="card"><div class="k">Staff</div><div class="v">{{ $selectedSummary['staff_id'] }} {{ $selectedSummary['staff_name'] }}</div></div>
                        <div class="card"><div class="k">Pay Total</div><div class="v">{{ $selectedSummary['pay_total'] }}</div></div>
                        <div class="card"><div class="k">Deduction Total</div><div class="v">{{ $selectedSummary['deduction_total'] }}</div></div>
                        <div class="card"><div class="k">Net Pay</div><div class="v">{{ $selectedSummary['net_pay'] }}</div></div>
                    </div>

                    <div class="actions">
                        <button type="button" class="btn" id="btn-edit">Edit</button>
                        <button type="submit" class="btn primary" id="btn-save" form="payload-save" style="display:none;">Save</button>
                        <button type="button" class="btn" id="btn-cancel" style="display:none;">Cancel</button>

                        <form method="POST" action="{{ route('admin.payroll-v2.sync-attendance') }}" style="margin:0;">
                            @csrf
                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                            <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <button type="submit" class="btn">Sync Attendance</button>
                        </form>

                        <form method="POST" action="{{ route('admin.payroll-v2.recalc-defaults') }}" style="margin:0;">
                            @csrf
                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                            <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <button type="submit" class="btn">Recalc Defaults</button>
                        </form>

                        <form method="POST" action="{{ route('admin.payroll-v2.recalc-koyou') }}" style="margin:0;">
                            @csrf
                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                            <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <button type="submit" class="btn">Recalc Koyou</button>
                        </form>

                        <form method="POST" action="{{ route('admin.payroll-v2.recalc-premium-deduction') }}" style="margin:0;">
                            @csrf
                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                            <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <button type="submit" class="btn">Recalc Premium/Deduction</button>
                        </form>

                        <form method="POST" action="{{ route('admin.payroll-v2.recalc-income-tax') }}" style="margin:0;">
                            @csrf
                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                            <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                            <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                            <button type="submit" class="btn">Recalc Income Tax</button>
                        </form>

                        @if($selectedSummary['is_edit_locked'])
                            <form method="POST" action="{{ route('admin.payroll-v2.unlock') }}" style="margin:0;">
                                @csrf
                                <input type="hidden" name="month" value="{{ $selectedMonth }}">
                                <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                                <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                                <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                                <button type="submit" class="btn">Unlock</button>
                            </form>
                        @else
                            <form method="POST" action="{{ route('admin.payroll-v2.lock') }}" style="margin:0;">
                                @csrf
                                <input type="hidden" name="month" value="{{ $selectedMonth }}">
                                <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                                <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                                <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                                <button type="submit" class="btn primary">Lock</button>
                            </form>
                        @endif
                    </div>

                    <form method="POST" action="{{ route('admin.payroll-v2.save') }}" id="payload-save">
                        @csrf
                        <input type="hidden" name="month" value="{{ $selectedMonth }}">
                        <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                        <input type="hidden" name="staff_id" value="{{ $selectedSummary['staff_id'] }}">
                        <input type="hidden" name="target_staff_id" value="{{ $selectedSummary['staff_id'] }}">
                        <input type="hidden" name="row" value="{{ $selectedSummary['staff_id'] }}">
                        <div class="payload" id="payload-box">
                            <div class="payload-grid">
                                @php
                                    $fixedSections = ['Attendance', 'Earnings', 'Deductions', 'BaseInfo', 'Others', 'Sales'];
                                @endphp
                                @foreach($fixedSections as $sectionName)
                                    @php
                                        $sectionRows = $selectedPayloadSections[$sectionName] ?? [];
                                    @endphp
                                    <div class="payload-section">
                                        <div class="payload-title">{{ $sectionName }}</div>
                                        <table>
                                            <thead><tr><th>Key</th><th>Value</th></tr></thead>
                                            <tbody>
                                            @forelse($sectionRows as $k => $v)
                                                @php
                                                    $disp = is_bool($v) ? ($v ? '1' : '0') : (is_numeric($v) ? number_format((float)$v, 4, '.', '') : (string)$v);
                                                    $editable = isset($editablePayloadKeys[$k]);
                                                @endphp
                                                <tr>
                                                    <th>{{ $k }}</th>
                                                    <td>
                                                        <span class="cell-view {{ $editable ? '' : 'cell-readonly' }}">{{ $disp }}</span>
                                                        @if($editable)
                                                            <input class="cell-input" type="text" name="fields[{{ $k }}]" value="{{ is_bool($v) ? ($v ? '1' : '0') : (string)$v }}">
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr><td colspan="2" class="empty">No fields.</td></tr>
                                            @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                @endforeach
                                @if(isset($selectedPayloadSections['Extras']) && is_array($selectedPayloadSections['Extras']) && count($selectedPayloadSections['Extras']) > 0)
                                    <div class="payload-section">
                                        <div class="payload-title">Extras</div>
                                        <table>
                                            <thead><tr><th>Key</th><th>Value</th></tr></thead>
                                            <tbody>
                                            @foreach($selectedPayloadSections['Extras'] as $k => $v)
                                                @php
                                                    $disp = is_bool($v) ? ($v ? '1' : '0') : (is_numeric($v) ? number_format((float)$v, 4, '.', '') : (string)$v);
                                                    $editable = isset($editablePayloadKeys[$k]);
                                                @endphp
                                                <tr>
                                                    <th>{{ $k }}</th>
                                                    <td>
                                                        <span class="cell-view {{ $editable ? '' : 'cell-readonly' }}">{{ $disp }}</span>
                                                        @if($editable)
                                                            <input class="cell-input" type="text" name="fields[{{ $k }}]" value="{{ is_bool($v) ? ($v ? '1' : '0') : (string)$v }}">
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </form>
                @endif
            </div>
        </div>
    </section>
</div>
<script>
function toggleSeed(){const el=document.getElementById('seed-box');if(el){el.classList.toggle('open');}}
function seedAll(on){document.querySelectorAll('.seed-target').forEach(el=>el.checked=!!on);}
function injectTargets(formId){
  const form=document.getElementById(formId); if(!form) return false;
  form.querySelectorAll('input[name="target_staff_ids[]"]').forEach(el=>el.remove());
  const checked=Array.from(document.querySelectorAll('.seed-target:checked')).map(el=>el.value);
  if(checked.length===0){alert('Select target staff.'); return false;}
  checked.forEach(id=>{const h=document.createElement('input');h.type='hidden';h.name='target_staff_ids[]';h.value=id;form.appendChild(h);});
  return true;
}
const payloadBox=document.getElementById('payload-box');
const btnEdit=document.getElementById('btn-edit');
const btnSave=document.getElementById('btn-save');
const btnCancel=document.getElementById('btn-cancel');
if(payloadBox && btnEdit && btnSave && btnCancel){
  btnEdit.addEventListener('click',()=>{
    payloadBox.classList.add('edit-mode');
    btnEdit.style.display='none';
    btnSave.style.display='inline-flex';
    btnCancel.style.display='inline-flex';
  });
  btnCancel.addEventListener('click',()=>{
    payloadBox.classList.remove('edit-mode');
    btnEdit.style.display='inline-flex';
    btnSave.style.display='none';
    btnCancel.style.display='none';
    const form=document.getElementById('payload-save');
    if(form){ form.reset(); }
  });
}
</script>
</body>
</html>
